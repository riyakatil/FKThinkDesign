import java.util.*;
import java.io.*;

class wheel{
	int rim;
	double tire;

	wheel(int rim,double tire){
		this.rim=rim;
		this.tire=tire;
	}

	double diameter(){return rim+(tire*2);}

	double circumference(){return this.diameter() *Math.PI;}
}


class Gear{
	
	int chainRing,cog;
	wheel w1;
	
	Gear(int chainRing,int cog,wheel w1){
		this.chainRing=chainRing;
		this.cog=cog;
		this.w1=w1;
	}


	double ratio(){
		return this.chainRing/this.cog;
	}

	double gearInches(){
		return this.ratio()*(w1.diameter());
	}


}

public class Ex3{
	public static void main(String args[]){

		wheel w1=new wheel(26,1.5);
		System.out.println(w1.diameter());
		Gear g1=new Gear(52,11,w1);
		System.out.println(g1.gearInches());
		System.out.println(g1.ratio());
				
	}
}