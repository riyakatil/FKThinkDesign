import java.util.*;
import java.io.*;

class Gear{
	int chainRing,cog;

	Gear(int chainRing,int cog){
		this.chainRing=chainRing;
		this.cog=cog;
	}


	float ratio(){
		return this.chainRing/this.cog;
	}


}

public class Ex1{
	public static void main(String args[]){

		float f1=new Gear(52,11).ratio();
		float f2=new Gear(30,27).ratio();

			System.out.println(f1);
			System.out.println(f2);
				
	}
}