import java.util.*;
import java.io.*;

class Gear{
	
	int chainRing,cog,rim;
	double tire;

	Gear(int chainRing,int cog,int rim,double tire){
		this.chainRing=chainRing;
		this.cog=cog;
		this.rim=rim;
		this.tire=tire;
	}


	double ratio(){
		return this.chainRing/this.cog;
	}

	double gearInches(){
		return this.ratio()*(this.rim +(this.tire*2));
	}


}

public class Ex2{
	public static void main(String args[]){

		double f1=new Gear(52,11,26,1.5).gearInches();
		double f2=new Gear(52,11,24,1.25).gearInches();

			System.out.println(f1);
			System.out.println(f2);
				
	}
}