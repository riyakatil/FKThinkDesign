

class ex1{
	public static void main (String [] args)
	{
	Gear obj1 = new Gear();
	obj1.rim = 26;
	obj1.tire = 1.5f;
	obj1.chainRing= 52;
	obj1.cog = 11;
	System.out.println(obj1.gearInches());
	}
}

 class Gear {


	int chainRing ;
	int cog;
	int rim;
	float tire;


	float ratio()
	{
		return chainRing/cog;
	}

	float gearInches()
	{
		Wheel wheel = new Wheel();
		wheel.rim =rim;
		wheel.tire = tire;
		return ratio()*wheel.diameter();
	}
}


class Wheel {

	int rim;
	float tire;
		


	

	float diameter()
	{
		return rim + (tire*2);

	} 


	}